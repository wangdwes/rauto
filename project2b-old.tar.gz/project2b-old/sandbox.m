
[im1, feats1, vpts1] = imload('left001.jpg');
[im2, feats2, vpts2] = imload('right001.jpg');

[matches] = matchFeatures(feats1, feats2);

locs1 = vpts1.Location(matches(:, 1), :);
locs2 = vpts2.Location(matches(:, 2), :); 

f1 = estimateFundamentalMatrix(locs1, locs2, 'Method', 'RANSAC')

f2 = transmat2' * ransacf([[1:size(locs1,1)]',[1:size(locs2, 1)]'], ...
   locs1, locs2, 500, 1e-6) * transmat1 
f3 = transmat2' * fundamat(locs1, locs2) * transmat1 
