
function [im, feats, vpts] = imload(fname, intriparams)

  % load the image and find out some interesting points.  
  im = im2double(rgb2gray(imread(fullfile('sensor', fname))));
  points = detectSURFFeatures(im);

  % find out the valid points and the features. 
  [feats, vpts] = extractFeatures(im, points); 
  [vpts] = horzcat(vpts.Location, ones(vpts.Count, 1)) * inv(intriparams)'; 

end

