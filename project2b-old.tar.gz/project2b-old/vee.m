function vec = vee(mat), 
vec = [mat(3, 2); mat(1, 3); mat(2, 1)];  

