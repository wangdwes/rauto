
function [rot, tr] = camtrf(locs1, locs2, em) 

  w = [0, -1, 0; 1, 0, 0; 0, 0, 1];
  % the essential matrix satisfies its internal constraint, so we can decompose it directly
  % to obtain the candidates for the rotation matrices and translational vectors. 
  [u, s, v] = svd(em); if det(u * w' * v') < 0, [u, s, v] = svd(-em); end;
  [rot1, rot2, tr1] = deal(u * w * v', u * w' * v', vee(v * w * s * v')'); tr2 = -tr1;

  % at this point we have four possible combinations of rotation and translation.
  % we would have to take one point pair and find one and only one correct combination.
  rotcandi = cat(3, rot1, rot1, rot2, rot2); trcandi = cat(3, tr1, tr2, tr1, tr2);
  tnom = rotcandi(1, :, :) - locs2(1, 1) * rotcandi(3, :, :);

  % z and zprime are the z coordinate values in the respective frames of both cameras.
  % should they all be positive, we have a valid solution. 
  z = sum(tnom .* trcandi, 2) ./ sum(bsxfun(@times, tnom, locs1(1, :)), 2);
  zprime = sum((bsxfun(@times, z, locs1(1, :)) - trcandi) .* rotcandi(3, :, :), 2);

  % warn the user if we're doomed, otherwise just return the rotation and translation. 
  selected = z(:) > 0 & zprime(:) > 0;
  assert(sum(selected) == 1, 'There are %d valid camera transformations.', sum(selected));
  rot = rotcandi(:, :, selected); tr = trcandi(:, :, selected)';

end
