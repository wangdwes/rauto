
function em = essmat(locs1, locs2) 

  % we're assuming that locs1 and locs2 are normalized homogeneous coordinates here.
  % this may not always achieve an optimal solution but it avoids repetitive computation
  % of similar data points in the ransac routine. 
  coeff = horzcat( ... 
    locs2(:, 1) .* locs1(:, 1), locs2(:, 1) .* locs1(:, 2), locs2(:, 1) .* locs1(:, 3), ...
    locs2(:, 2) .* locs1(:, 1), locs2(:, 2) .* locs1(:, 2), locs2(:, 2) .* locs1(:, 3), ...
    locs2(:, 3) .* locs1(:, 1), locs2(:, 3) .* locs1(:, 2), locs2(:, 3) .* locs1(:, 3)); 
  
  % use eig instead svd to save a tiny amount of computation time. 
  [eigenvecs, eigenvals] = eig(coeff' * coeff);
  [~, index] = min(diag(eigenvals)); emtilde = eigenvecs(:, index);

  % an essential matrix has two equal eigenvalues and one zero eigenvalue.
  % here we take its singular value decomposition (svd) to enforce this constraint. 
  [leftevi, eeva, rightevi] = svd(reshape(emtilde, 3, 3)'); eeva(end) = 0; eeva(5) = eeva(1);
  [em] = leftevi * eeva * rightevi'; 

end
  
