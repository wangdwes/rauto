
function [locs1, locs2, beste] = findmatch(f1, vpts1, f2, vpts2)

  % obtain the matched features and retrieve their locations.
  [matches] = matchFeatures(f1, f2);
  [locs1, transmat1] = normalize(vpts1(matches(:, 1), :));
  [locs2, transmat2] = normalize(vpts2(matches(:, 2), :)); 

  % invoke the ransac routine to find the best essential matrix. 
  [beste, inliers] = ransace(locs1, locs2, 500, 1e-3);
  [locs1, locs2] = deal(locs1(inliers, :) * inv(transmat1)', ...
                        locs2(inliers, :) * inv(transmat2)');

  % de-normalize the essential matrix.  
  beste = transmat2' * beste * transmat1;

end
